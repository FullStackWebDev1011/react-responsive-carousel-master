import { addons } from '@storybook/addons';

addons.setConfig({
    showPanel: true,
    panelPosition: 'right',
});
