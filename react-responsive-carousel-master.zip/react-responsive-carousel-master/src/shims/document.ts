export default () => document;
