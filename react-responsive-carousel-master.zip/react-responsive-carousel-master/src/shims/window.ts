export default () => window;
