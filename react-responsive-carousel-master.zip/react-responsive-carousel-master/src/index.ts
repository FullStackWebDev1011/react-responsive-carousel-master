export { default as Carousel } from './components/Carousel';
export { CarouselProps } from './components/Carousel/types';
export { default as Thumbs } from './components/Thumbs';
